import { libellePaiement, type Payeur } from "@/lib/tarifs";
import type { CareScheme, PaymentMethod, PaymentStatus, SessionStatus } from "@prisma/client";
import {
  METHOD_LABEL,
  PAYMENT_LABEL,
  SCHEME_LABEL,
  STATUS_LABEL,
  adresseCabinet,
  isBillable,
  type CabinetVue,
} from "@/lib/format";

/**
 * Titre d'une section de réglages ou d'un long écran de gestion, sur la même
 * bande mauve que le site public plutôt qu'un simple texte gras.
 *
 * Une page comme Réglages a grossi au point de mériter une hiérarchie plus
 * marquée — la couleur du site sert ici à faire sauter le début de chaque
 * section au regard, pas à en dire le sens : elle reste réservée à ce rôle
 * unique, distinct des trois familles chromatiques du reste de l'outil
 * (paiement, cabinet, accent).
 */
export function TitreSection({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="rounded-[14px] bg-bande-violette px-5 py-3 font-display text-xl text-nuit">
      {children}
    </h2>
  );
}

/**
 * Contrainte chromatique : plusieurs familles de sens se disputent une même
 * ligne. L'état de paiement garde la couleur pleine — ambre, vert, rouge. Les
 * cabinets portent chacun la leur, choisie dans une palette vérifiée. Restent
 * le régime et le statut de séance, tous deux traités sans couleur.
 *
 * Les couleurs de cabinet venant de la base, elles passent par des styles en
 * ligne et non par des classes : une classe Tailwind ne peut pas être générée
 * pour une valeur qui n'existe qu'à l'exécution.
 */

export function Tag({
  children,
  tone = "neutre",
  titre,
}: {
  children: React.ReactNode;
  tone?: "neutre" | "contour";
  titre?: string;
}) {
  const styles = {
    neutre: "bg-sunken text-ink-muted",
    contour: "border border-line-strong text-ink-muted",
  }[tone];
  return (
    <span
      title={titre}
      className={`inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-medium whitespace-nowrap ${styles}`}
    >
      {children}
    </span>
  );
}

export function RegimeTag({ scheme }: { scheme: CareScheme }) {
  return <Tag tone={scheme === "PRIVE" ? "neutre" : "contour"}>{SCHEME_LABEL[scheme]}</Tag>;
}

export function CabinetTag({ cabinet }: { cabinet: CabinetVue }) {
  return (
    <span
      title={adresseCabinet(cabinet)}
      style={
        {
          "--cab": cabinet.colorHex,
          "--cab-fill": cabinet.fillHex,
          "--cab-vif": cabinet.vividHex,
        } as React.CSSProperties
      }
      className="teinte-cabinet inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-medium whitespace-nowrap"
    >
      <span aria-hidden="true" className="filet-cabinet h-1.5 w-1.5 rounded-full" />
      {cabinet.nom}
    </span>
  );
}

export function StatutSeance({ status }: { status: SessionStatus }) {
  const emphase = status === "NO_SHOW" ? "font-semibold text-ink" : "text-ink-muted";
  return <span className={`text-xs whitespace-nowrap ${emphase}`}>{STATUS_LABEL[status]}</span>;
}

export function EtatPaiement({
  status,
  payment,
  methode,
  payeur = "PATIENT",
}: {
  status: SessionStatus;
  payment: PaymentStatus;
  methode?: PaymentMethod | null;
  /** Qui règle : le patient (« dû », « payé ») ou l'INAMI (« à recevoir », « reçu »). */
  payeur?: Payeur;
}) {
  if (!isBillable(status)) return <span className="text-ink-muted">—</span>;

  const styles: Record<PaymentStatus, string> = {
    DUE: "bg-due-soft text-due",
    PAID: "bg-paid-soft text-paid",
    OVERDUE: "bg-overdue-soft text-overdue",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold whitespace-nowrap ${styles[payment]}`}
    >
      {libellePaiement(payment, payeur)}
      {payment === "PAID" && payeur === "INAMI"
        ? " · INAMI"
        : payment === "PAID" && methode
          ? ` · ${METHOD_LABEL[methode]}`
          : ""}
    </span>
  );
}

export function AlerteTrajet() {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-overdue/40 bg-overdue-soft px-2.5 py-0.5 text-[11px] font-semibold text-overdue">
      <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true">
        <path
          d="M6 1 11.2 10.5H0.8L6 1Z M6 4.6v2.6 M6 8.6v.5"
          stroke="currentColor"
          strokeWidth="1.1"
          strokeLinejoin="round"
          fill="none"
        />
      </svg>
      trajet trop court
    </span>
  );
}
