#!/usr/bin/env bash
# Envoie le code du Mac vers le serveur, le compile et relance l'app.
# À lancer depuis le dossier du projet, à chaque mise en ligne :
#   bash deploy/deployer.sh root@ADRESSE_IP
#
# Les secrets viennent de .env.production (jamais versionné), à créer une fois
# depuis Vercel : voir deploy/LISEZMOI.md. DATABASE_URL et DIRECT_URL y sont
# ignorées : le serveur utilise sa propre base locale.
set -euo pipefail

HOTE="${1:?Usage : bash deploy/deployer.sh root@ADRESSE_IP}"
cd "$(dirname "$0")/.."

[ -f .env.production ] || { echo ".env.production manquant (voir deploy/LISEZMOI.md)."; exit 1; }
for V in AUTH_SECRET AUTH_PASSWORD_HASH_B64 GOOGLE_CLIENT_ID GOOGLE_CLIENT_SECRET GOOGLE_TOKEN_KEY CRON_SECRET AGENDA_TOKEN; do
  grep -qE "^$V=.+" .env.production || echo "Avertissement : $V absente ou vide dans .env.production."
done

echo "== Envoi du code"
rsync -az --delete \
  --exclude node_modules --exclude .next --exclude .git --exclude .vercel \
  --exclude '.env*' --exclude .DS_Store --exclude .claude --exclude .design \
  ./ "$HOTE:/srv/psy/app/"

echo "== Envoi des secrets"
grep -vE '^(DATABASE_URL|DIRECT_URL|VERCEL_[A-Z_]*|NODE_ENV|DEMO_OUVERTE|GOOGLE_REDIRECT_URI)=' .env.production \
  | ssh "$HOTE" 'cat /srv/psy/config/env.base - > /srv/psy/app/.env && chown psy:psy /srv/psy/app/.env && chmod 600 /srv/psy/app/.env'

echo "== Installation, migrations et compilation sur le serveur"
ssh "$HOTE" 'set -e
  chown -R psy:psy /srv/psy/app
  cd /srv/psy/app
  sudo -u psy -H npm ci --no-audit --no-fund
  sudo -u psy -H npm run build
  systemctl restart pratique-psy
  sleep 3
  systemctl --no-pager --lines=5 status pratique-psy'

echo
echo "Déployé."
