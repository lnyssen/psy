#!/usr/bin/env bash
# Copie toutes les données de Neon (patients, séances, factures, photos des
# dépenses) dans la base du serveur. À lancer UNE fois, avant le premier
# déploiement, depuis le dossier du projet :
#   bash deploy/importer-neon.sh root@ADRESSE_IP
#
# Neon n'est pas modifié : on ne fait que le lire.
set -euo pipefail

HOTE="${1:?Usage : bash deploy/importer-neon.sh root@ADRESSE_IP}"
cd "$(dirname "$0")/.."

NEON="$(grep -E '^DIRECT_URL=' .env.local | head -1 | cut -d= -f2- | tr -d '"')"
[ -n "$NEON" ] || { echo "DIRECT_URL introuvable dans .env.local."; exit 1; }

# L'adresse de Neon passe par l'entrée standard, pour ne pas apparaître dans la
# liste des processus du serveur.
printf '%s\n' "$NEON" | ssh "$HOTE" 'set -euo pipefail
  read -r NEON
  LOCALE="$(grep -E "^DATABASE_URL=" /srv/psy/config/env.base | cut -d= -f2- | tr -d "\"")"
  TABLES="$(psql "$LOCALE" -tAc "select count(*) from information_schema.tables where table_schema = '\''public'\''")"
  if [ "$TABLES" != "0" ]; then
    echo "La base du serveur contient déjà des tables : import annulé pour ne rien écraser."
    exit 1
  fi
  echo "pg_dump : $(pg_dump --version)"
  # Neon exige un certificat vérifié : on utilise les autorités du système.
  case "$NEON" in *sslrootcert=*) ;; *) NEON="$NEON&sslrootcert=system" ;; esac
  pg_dump --no-owner --no-acl -Fc "$NEON" > /root/neon-import.dump
  # Quelques avertissements bénins sont possibles (schéma public déjà présent).
  pg_restore --no-owner --no-acl -d "$LOCALE" /root/neon-import.dump || echo "(pg_restore a signalé des avertissements, voir ci-dessus)"
  rm -f /root/neon-import.dump
  echo "Tables importées : $(psql "$LOCALE" -tAc "select count(*) from information_schema.tables where table_schema = '\''public'\''")"
  echo "Patients : $(psql "$LOCALE" -tAc "select count(*) from patients" 2>/dev/null || echo "?")"'

echo "Import terminé."
