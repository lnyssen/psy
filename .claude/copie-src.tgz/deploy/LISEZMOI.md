# Mise en ligne de Pratique Psy sur one.com

Toutes les commandes se tapent dans le **Terminal du Mac**.

## 1. Pointer le domaine vers le serveur (panneau one.com)

Dans **DNS** du domaine, crée ou modifie deux enregistrements **A** :

| Nom | Type | Valeur |
| --- | --- | --- |
| `@` (le domaine nu) | A | `85.190.112.171` |
| `www` | A | `85.190.112.171` |

S’il existe déjà des enregistrements A ou AAAA pour `@` ou `www` (page de parking one.com), modifie-les ou supprime-les, sinon le certificat HTTPS échouera.

La propagation peut prendre de quelques minutes à quelques heures. On continue pendant ce temps.

## 2. Se connecter au serveur avec une clé SSH

```bash
# Crée une clé si tu n’en as pas encore (Entrée à chaque question)
[ -f ~/.ssh/id_ed25519 ] || ssh-keygen -t ed25519

# Installe la clé sur le serveur (demande le mot de passe root donné par one.com)
ssh-copy-id root@85.190.112.171

# Vérifie : doit se connecter SANS mot de passe, puis tape exit
ssh root@85.190.112.171
```

## 3. Installer le serveur (une seule fois)

```bash
cd ~/Projets/pratique-psy
scp deploy/installer-serveur.sh root@85.190.112.171:
ssh root@85.190.112.171 'bash installer-serveur.sh amandinemonsel.be amandine.monsel@gmail.com'
```

À la fin, le script affiche la **clé des sauvegardes** : copie-la dans ton gestionnaire de mots de passe.

## 4. Récupérer les secrets depuis Vercel (une seule fois)

```bash
cd ~/Projets/pratique-psy
npx vercel env pull .env.production --environment=production
```

Ouvre `.env.production` et vérifie que ces variables ont une valeur : `AUTH_SECRET`, `AUTH_PASSWORD_HASH_B64`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_TOKEN_KEY`, `CRON_SECRET`, `AGENDA_TOKEN`. Si l’une est vide (variable marquée « sensible » chez Vercel), recopie-la à la main depuis Vercel → Settings → Environment Variables. **`GOOGLE_TOKEN_KEY` doit rester identique** : elle déchiffre la connexion Google déjà enregistrée.

## 5. Copier les données de Neon vers le serveur (une seule fois)

```bash
bash deploy/importer-neon.sh root@85.190.112.171
```

Le script affiche le nombre de patients importés : compare avec l’app actuelle.

## 6. Mettre l’app en ligne

```bash
bash deploy/deployer.sh root@85.190.112.171
```

C’est aussi la commande à relancer **à chaque nouvelle version**.

## 7. Google Agenda

Dans Google Cloud Console → Identifiants → le client OAuth, ajoute l’URI de redirection :

```
https://amandinemonsel.be/api/google/callback
```

Garde l’ancienne (Vercel) tant que la bascule n’est pas terminée.

## 8. Vérifier

- `https://amandinemonsel.be` s’ouvre avec le cadenas.
- Connexion avec le mot de passe habituel.
- Une fiche patient et une photo de dépense s’affichent.
- Réglages → Google Agenda : la synchro fonctionne.

## Ensuite

- Sauvegardes hors serveur : `bash deploy/recuperer-sauvegardes.sh root@85.190.112.171` (par exemple une fois par semaine).
- Une fois tout vérifié : couper le projet Vercel et la base Neon, pour ne pas garder de copie des données ailleurs.
