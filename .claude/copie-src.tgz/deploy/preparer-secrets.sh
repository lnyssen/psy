#!/usr/bin/env bash
# Complète .env.production pour le serveur, quand Vercel refuse de rendre ses
# secrets (« [SENSITIVE] »). À lancer depuis le dossier du projet :
#   bash deploy/preparer-secrets.sh
#
# Pour chaque variable : garde la valeur déjà lisible dans .env.production,
# sinon la reprend de .env.local, sinon la génère ou la demande.
# N'affiche jamais une valeur.
set -euo pipefail
cd "$(dirname "$0")/.."

lire() { # lire FICHIER VAR -> valeur sans guillemets, vide si absente ou masquée
  [ -f "$1" ] || return 0
  local v
  v="$(grep -E "^$2=" "$1" | tail -1 | cut -d= -f2- | sed -E 's/^"(.*)"$/\1/')"
  [ "$v" = "[SENSITIVE]" ] && v=""
  printf '%s' "$v"
}

VARS="AUTH_SECRET AUTH_PASSWORD_HASH_B64 AGENDA_TOKEN GOOGLE_CLIENT_ID GOOGLE_CLIENT_SECRET GOOGLE_TOKEN_KEY CRON_SECRET"
# bash 3 (celui du Mac) : pas de tableaux associatifs, une variable par nom.
poser() { printf -v "VAL_$1" '%s' "$2"; printf -v "ORI_$1" '%s' "$3"; }
val() { local n="VAL_$1"; printf '%s' "${!n}"; }

for V in $VARS; do
  v="$(lire .env.production "$V")"; o="Vercel"
  if [ -z "$v" ]; then v="$(lire .env.local "$V")"; o=".env.local"; fi
  poser "$V" "$v" "$o"
done

[ -n "$(val GOOGLE_TOKEN_KEY)" ] || poser GOOGLE_TOKEN_KEY "$(openssl rand -base64 32)" "nouvelle (il faudra reconnecter Google Agenda)"
[ -n "$(val CRON_SECRET)" ] || poser CRON_SECRET "$(openssl rand -hex 32)" "nouvelle"
[ -n "$(val AGENDA_TOKEN)" ] || poser AGENDA_TOKEN "$(openssl rand -hex 24)" "nouvelle (l'adresse du flux iCal change)"
[ -n "$(val AUTH_SECRET)" ] || poser AUTH_SECRET "$(openssl rand -hex 32)" "nouvelle"

if [ -z "$(val GOOGLE_CLIENT_ID)" ]; then
  read -r -p "ID client Google (se termine par .apps.googleusercontent.com) : " S
  poser GOOGLE_CLIENT_ID "$S" "saisie"
fi
if [ -z "$(val GOOGLE_CLIENT_SECRET)" ]; then
  read -r -s -p "Code secret du client Google (la saisie reste invisible) : " S; echo
  poser GOOGLE_CLIENT_SECRET "$S" "saisie"
fi
if [ -z "$(val AUTH_PASSWORD_HASH_B64)" ]; then
  echo "AUTH_PASSWORD_HASH_B64 introuvable : impossible de se connecter à l'app sans elle."; exit 1
fi

{
  echo "# Secrets du serveur one.com, générés par deploy/preparer-secrets.sh. Ne jamais versionner."
  for V in $VARS; do printf '%s="%s"\n' "$V" "$(val "$V")"; done
} > .env.production
chmod 600 .env.production

echo
echo "Fichier .env.production prêt :"
for V in $VARS; do n="ORI_$V"; printf '  %-24s %s\n' "$V" "${!n}"; done
