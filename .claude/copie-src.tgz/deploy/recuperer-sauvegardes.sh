#!/usr/bin/env bash
# Rapatrie sur le Mac les sauvegardes chiffrées du serveur (copie hors de one.com).
#   bash deploy/recuperer-sauvegardes.sh root@ADRESSE_IP
# Les fichiers restent chiffrés : sans la clé notée à l'installation, ils sont illisibles.
set -euo pipefail
HOTE="${1:?Usage : bash deploy/recuperer-sauvegardes.sh root@ADRESSE_IP}"
DEST="$HOME/Sauvegardes/pratique-psy"
mkdir -p "$DEST"
rsync -az "$HOTE:/var/backups/psy/" "$DEST/"
echo "Sauvegardes à jour dans $DEST :"
ls -1t "$DEST" | head -5
