#!/usr/bin/env bash
# Prépare un serveur Ubuntu neuf pour Pratique Psy. À lancer UNE fois, en root :
#   bash installer-serveur.sh mondomaine.be adresse@email.be
#
# Installe : pare-feu, correctifs de sécurité automatiques, fail2ban, Node.js,
# PostgreSQL (base locale), Caddy (HTTPS automatique), le service de l'app,
# la tâche quotidienne Google Agenda et la sauvegarde chiffrée de la base.
set -euo pipefail

DOMAINE="${1:?Usage : installer-serveur.sh mondomaine.be email@exemple.be}"
EMAIL="${2:?Usage : installer-serveur.sh mondomaine.be email@exemple.be}"
APP=/srv/psy
UTILISATEUR=psy

[ "$(id -u)" -eq 0 ] || { echo "À lancer en root."; exit 1; }
export DEBIAN_FRONTEND=noninteractive

echo "== Paquets de base"
apt-get update -y
apt-get upgrade -y
apt-get install -y curl ca-certificates gnupg rsync ufw fail2ban unattended-upgrades \
  postgresql postgresql-client cron

echo "== Correctifs de sécurité automatiques"
cat > /etc/apt/apt.conf.d/20auto-upgrades <<'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
EOF

echo "== Pare-feu (SSH, HTTP, HTTPS uniquement)"
ufw allow OpenSSH
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
systemctl enable --now fail2ban

echo "== Node.js 24 LTS"
if ! command -v node >/dev/null || [ "$(node -v | cut -d. -f1)" != "v24" ]; then
  curl -fsSL https://deb.nodesource.com/setup_24.x | bash -
  apt-get install -y nodejs
fi
node -v

echo "== Caddy (serveur web et certificat HTTPS)"
if ! apt-get install -y caddy; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y && apt-get install -y caddy
fi
cat > /etc/caddy/Caddyfile <<EOF
{
	email $EMAIL
}

$DOMAINE, www.$DOMAINE {
	encode zstd gzip
	reverse_proxy 127.0.0.1:3000
}
EOF
systemctl reload caddy || systemctl restart caddy

echo "== Utilisateur et dossiers"
id "$UTILISATEUR" >/dev/null 2>&1 || useradd --system --create-home --home-dir "$APP" --shell /usr/sbin/nologin "$UTILISATEUR"
mkdir -p "$APP/app" "$APP/config"
chown -R "$UTILISATEUR:$UTILISATEUR" "$APP"
chmod 750 "$APP"

echo "== Base PostgreSQL locale"
if [ ! -f "$APP/config/env.base" ]; then
  MDP="$(openssl rand -hex 24)"
  sudo -u postgres psql -v ON_ERROR_STOP=1 <<EOF
CREATE ROLE $UTILISATEUR LOGIN PASSWORD '$MDP';
CREATE DATABASE $UTILISATEUR OWNER $UTILISATEUR;
EOF
  URL="postgresql://$UTILISATEUR:$MDP@127.0.0.1:5432/$UTILISATEUR"
  cat > "$APP/config/env.base" <<EOF
# Généré par installer-serveur.sh : base locale du serveur.
DATABASE_URL="$URL"
DIRECT_URL="$URL"
NODE_ENV="production"
# Derrière Caddy, l'app se voit servie en http : on fixe l'adresse de retour Google.
GOOGLE_REDIRECT_URI="https://$DOMAINE/api/google/callback"
EOF
  chown "$UTILISATEUR:$UTILISATEUR" "$APP/config/env.base"
  chmod 600 "$APP/config/env.base"
fi

echo "== Service de l'application"
cat > /etc/systemd/system/pratique-psy.service <<EOF
[Unit]
Description=Pratique Psy (Next.js)
After=network.target postgresql.service

[Service]
User=$UTILISATEUR
WorkingDirectory=$APP/app
ExecStart=/usr/bin/npx next start -H 127.0.0.1 -p 3000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable pratique-psy

echo "== Tâche quotidienne Google Agenda (05:00, comme sur Vercel)"
cat > /usr/local/bin/psy-cron <<'EOF'
#!/usr/bin/env bash
SECRET="$(grep -E '^CRON_SECRET=' /srv/psy/app/.env | head -1 | cut -d= -f2- | tr -d '"')"
[ -n "$SECRET" ] || { echo "CRON_SECRET absente" >&2; exit 1; }
curl -fsS -m 300 -H "Authorization: Bearer $SECRET" http://127.0.0.1:3000/api/google/cron
EOF
chmod 750 /usr/local/bin/psy-cron

echo "== Sauvegarde chiffrée quotidienne de la base (02:30, 30 jours gardés)"
mkdir -p /var/backups/psy && chmod 700 /var/backups/psy
if [ ! -f /root/.psy-sauvegarde-cle ]; then
  openssl rand -base64 32 > /root/.psy-sauvegarde-cle
  chmod 600 /root/.psy-sauvegarde-cle
  NOUVELLE_CLE=1
fi
cat > /usr/local/bin/psy-sauvegarde <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
F="/var/backups/psy/psy-$(date +%Y-%m-%d).dump.gpg"
sudo -u postgres pg_dump -Fc psy \
  | gpg --batch --yes --symmetric --cipher-algo AES256 \
        --passphrase-file /root/.psy-sauvegarde-cle -o "$F"
chmod 600 "$F"
find /var/backups/psy -name 'psy-*.dump.gpg' -mtime +30 -delete
EOF
chmod 750 /usr/local/bin/psy-sauvegarde

cat > /etc/cron.d/pratique-psy <<'EOF'
SHELL=/bin/bash
30 2 * * * root /usr/local/bin/psy-sauvegarde >> /var/log/psy-sauvegarde.log 2>&1
0 5 * * * root /usr/local/bin/psy-cron >> /var/log/psy-cron.log 2>&1
EOF

echo "== SSH : connexion par clé uniquement (si une clé est déjà installée)"
if [ -s /root/.ssh/authorized_keys ]; then
  cat > /etc/ssh/sshd_config.d/10-psy.conf <<'EOF'
PasswordAuthentication no
PermitRootLogin prohibit-password
EOF
  systemctl reload ssh || systemctl reload sshd || true
  echo "   Mots de passe SSH désactivés."
else
  echo "   ATTENTION : aucune clé SSH pour root, mots de passe laissés actifs."
fi

echo
echo "Serveur prêt. Étapes suivantes : importer-neon.sh puis deployer.sh, depuis le Mac."
if [ "${NOUVELLE_CLE:-0}" = 1 ]; then
  echo
  echo "CLÉ DES SAUVEGARDES, à noter dans ton gestionnaire de mots de passe :"
  cat /root/.psy-sauvegarde-cle
  echo "Sans elle, les sauvegardes sont illisibles."
fi
